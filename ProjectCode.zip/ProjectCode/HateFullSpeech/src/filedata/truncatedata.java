
package filedata;

import Master.Dbconn;
import java.sql.Connection;
import java.sql.Statement;
/**
 *
 * @author JP
 */
public class truncatedata {

    public static void truncatemaster() {
        Connection con;
        try {
            con = Dbconn.conn();

            Statement st1 = (Statement) con.createStatement();
            Statement st2 = (Statement) con.createStatement();
            Statement st3 = (Statement) con.createStatement();
            Statement st4 = (Statement) con.createStatement();
            Statement st5 = (Statement) con.createStatement();
            Statement st6 = (Statement) con.createStatement();
            Statement st7 = (Statement) con.createStatement();
            st1.executeQuery("TRUNCATE table twitterdata");
               st2.executeQuery("TRUNCATE table nlpTrain");
               st3.executeQuery("TRUNCATE table nlptest");
               st4.executeQuery("TRUNCATE table trainingdata70");
               st5.executeQuery("TRUNCATE table testingdata30");
                
          
           

        } catch (Exception e) {
        }

    }

    public static void main(String[] agrs) {
      
    }

}
