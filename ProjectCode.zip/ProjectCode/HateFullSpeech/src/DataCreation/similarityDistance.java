package DataCreation;

import static DataCreation.semantic_features.laughing_expressions;
import Master.Dbconn;
import static Master.Dbconn.positive;
import static Master.Dbconn.temp;
import static Master.Dbconn.neg;
import static Master.Dbconn.negative;
import static Master.Dbconn.stopwordspath;
import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author JP
 */
public class similarityDistance {
    public  static String data=null;
    public static int record=0;
    public static void main(String[] args) {
	 getSimilarity();
	   
	  }
    public static void getSimilarity()
    {
        double th=0.59,th1=0.30;
        double flag=0;
        double nflag=0;
        Scanner sc,sc1;
        Connection con;
        
        try {
            con = Dbconn.conn();
            Statement st4 = con.createStatement();
        st4.executeUpdate("TRUNCATE table tblclasses");
        Statement st = con.createStatement();
        st.executeQuery("select count(*) from tblstopwordsstemmer");
        ResultSet rs = st.getResultSet();
       
        if (rs.next()) {
        record=Integer.parseInt(rs.getString(1));
            }
        
        Statement st1 = con.createStatement();
        st1.executeQuery("select * from tblstopwordsstemmer");
        ResultSet rs1 = st1.getResultSet();
      String id,username=null;
        while (rs1.next()) {
            id=rs1.getString("id");
            username=rs1.getString("UserName");
        data=rs1.getString("Stemmerword").replace("∞", "");
    
//        String[] tokens = data.split("\\P{Alpha}+");// \\p is use for space and
String[] tokens = data.split(",");        
// {Alpha for (')eg it's}

//Positive        
        for (String s : tokens) {
            sc = new Scanner(new File(temp));

            while (sc.hasNext()) {
                if (sc.next().toLowerCase().equals(s.toLowerCase())) {
                    flag ++;
                    break;
                } 
            }// while loop end   
        }// for loop end
        
        //Negative       
        for (String s : tokens) {
            sc1 = new Scanner(new File(neg));

            while (sc1.hasNext()) {
                if (sc1.next().toLowerCase().equals(s.toLowerCase())) {
                    nflag ++;
                   break;
                } 
            }// while loop end
        }// for loop end
        
        int laugh =laughing_expressions(data);
        int express=laughing_expressions(data);
        
//positive flag
        DecimalFormat df = new DecimalFormat("#0.00");
        DecimalFormat df1 = new DecimalFormat("#0.00");
        double score=(flag/tokens.length);
        String ss=df.format(score);
        double weight=Double.parseDouble(ss);
            System.out.println("ID=>"+id+"\tScore=>"+ss+"\t Flag=>"+flag);

        double nscore=nflag/tokens.length;
        String nss=df1.format(nscore);
        double nWeight=Double.parseDouble(nss);
        System.out.println("ID=>"+id+"\tScore=>"+nss+"\t nFlag=>"+nflag);
            flag=0.0;
            nflag=0.0;
        String classname=null;
        if(weight>=th)
        {
            //ss=String.valueOf(weight);
        classname="Positive";
        
        }
        else if(nWeight>=th)
        {
                    ss=nss;
            // ss=String.valueOf(nWeight);
        classname="Negative";
        }
        else
        {
            classname="clean";
        }

        Statement st3 = con.createStatement();
        st3.executeUpdate("insert into tblclasses values('"+id+"','"+username+"','"+data+"','"+ss+"','"+classname+"','"+tokens.length+"')");
        }// db while loop end
    } catch (Exception ex) {
            //Logger.getLogger(similarityDistance.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(ex);    
    ex.printStackTrace();
    }
    
    }
    
}
