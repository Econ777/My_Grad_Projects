/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataCreation;
//
//import static DataCreation.LatLng.getLatLongPositions;

import static DataCreation.demotwitter.datecount;
import static DataCreation.demotwitter.datecount1;
import static DataCreation.demotwitter.getOAuth2Token;
import static DataCreation.demotwitter.getTwitter;
import Master.Dbconn;
import Preprocess.RemoveStopwords;
import static Preprocess.RemoveStopwords.negativetopics;
import static Preprocess.RemoveStopwords.positivetopics;
import Preprocess.Stemmer;
import Preprocess.emoticon;
import filedata.AgeCalculator;
//import filedata.AgeCalculator;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import timezone.TimeZoneId;
import static timezone.genderize.genderizeiddata;

import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.RateLimitStatus;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.auth.OAuth2Token;
import twitter4j.conf.ConfigurationBuilder;

/**
 *
 * @author JP
 */
public class demotwitter {

    public static ArrayList<String> alllistdata = new ArrayList<>();
    public static ArrayList<String> finaldata = new ArrayList<>();
    public static BufferedWriter bw = null;

    public static String[] str = null;
    //	Set this to your actual CONSUMER KEY and SECRET for your application as given to you by dev.twitter.com
    public static final String CONSUMER_KEY = "GYHBUo8z89qXKzw0NwVriWVq2";
    public static final String CONSUMER_SECRET = "ZC0PebtFD44ZGIwHSx2JfahuOd8PjGxvEfS194g5BHSN7Ojwoy";
    //	How many tweets to retrieve in every call to Twitter. 100 is the maximum allowed in the API
    public static final int TWEETS_PER_QUERY = 5;

    //	This controls how many queries, maximum, we will make of Twitter before cutting off the results.
    //	You will retrieve up to MAX_QUERIES*TWEETS_PER_QUERY tweets.
    //  If you set MAX_QUERIES high enough (e.g., over 450), you will undoubtedly hit your rate limits
    //  and you an see the program sleep until the rate limits reset
    public static final int MAX_QUERIES = 100;
    public static String msg11, msg22;
    public static String age, gender, username, userScreenName, createddate, profilename, location, language, friendcount, followerscount, statuscount, listedcount, timezone, utcoffset, latitude, longitude, tweentpost, userurl, tweentcount;
    public static String tweetsid = "U", tweetsidtotal, tweetsids, desc;
    public static int retweets;
    int tweetid = 0;
    //	What we want to search for in this program.  Justin Bieber always returns as many results as you could
    //	ever want, so it's safe to assume we'll get multiple pages back...
    public static final String SEARCH_TERM = "School";

    public static String cleanText(String text) {
        text = text.replace("\n", "\\n");
        text = text.replace("\t", "\\t");
        return text;
    }

    public static OAuth2Token getOAuth2Token() {
        OAuth2Token token = null;
        ConfigurationBuilder cb;
        cb = new ConfigurationBuilder();
        cb.setApplicationOnlyAuthEnabled(true);
        cb.setOAuthConsumerKey(CONSUMER_KEY).setOAuthConsumerSecret(CONSUMER_SECRET);
        try {
            token = new TwitterFactory(cb.build()).getInstance().getOAuth2Token();
        } catch (TwitterException e) {
            System.out.println("Could not get OAuth2 token");
            System.exit(0);
        }
        return token;
    }

    public static Twitter getTwitter() {
        OAuth2Token token;		//	First step, get a "bearer" token that can be used for our requests
        token = getOAuth2Token();
        ConfigurationBuilder cb = new ConfigurationBuilder();
        cb.setApplicationOnlyAuthEnabled(true);
        cb.setOAuthConsumerKey(CONSUMER_KEY);
        cb.setOAuthConsumerSecret(CONSUMER_SECRET);
        cb.setOAuth2TokenType(token.getTokenType());
        cb.setOAuth2AccessToken(token.getAccessToken());	//	And create the Twitter object!
        return new TwitterFactory(cb.build()).getInstance();
    }

    public static void createaccount(String topics) {
        int ids = 0;
        Statement stat, stat1;
        Connection con;
        try {
            con = Dbconn.conn();

            stat = (Statement) con.createStatement();
            stat1 = (Statement) con.createStatement();
            stat.executeQuery("select * from twitterdata order by UID desc");
            ResultSet rs;
            ResultSet rs1;
            rs = stat.getResultSet();
            if (rs.next()) {
                stat1.executeQuery("select * from twitterdata order by UID desc");
                rs1 = stat1.getResultSet();
                if (rs1.next()) {
                    int a = Integer.valueOf(rs1.getString(1));
                    ids = a + 1;
                }
            } else {
                ids = 1;
            }
        } catch (Exception ex) {
            Logger.getLogger(demotwitter.class.getName()).log(Level.SEVERE, null, ex);
        }
        // alllistdata.clear();
        int totalTweets = 0;//	This variable is the key to our retrieving multiple blocks of tweets.  In each batch of tweets we retrieve,
        long maxID = -1;
        Twitter twitter = getTwitter();	//	Now do a simple search to show that the tokens work

        try {
            Connection conn = Dbconn.conn();
            Map<String, RateLimitStatus> rateLimitStatus = twitter.getRateLimitStatus("search");
            RateLimitStatus searchTweetsRateLimit = rateLimitStatus.get("/search/tweets");
            System.out.printf("You have %d calls remaining out of %d, Limit resets in %d seconds\n",
                    searchTweetsRateLimit.getRemaining(),
                    searchTweetsRateLimit.getLimit(),
                    searchTweetsRateLimit.getSecondsUntilReset());

            for (int queryNumber = 0; queryNumber < MAX_QUERIES; queryNumber++) {// frist
                if (searchTweetsRateLimit.getRemaining() == 0) {
                    Thread.sleep((searchTweetsRateLimit.getSecondsUntilReset() + 2) * 1000l);
                }

                Query q = new Query(topics);			// Search for tweets that contains this term
                q.setCount(TWEETS_PER_QUERY);				// How many tweets, max, to retrieve
                //q.resultType("recent");						// Get all tweets
                q.setLang("en");							// English language tweets, please
                if (maxID != -1) {
                    q.setMaxId(maxID - 1);
                }
                QueryResult r = twitter.search(q);
                if (r.getTweets().isEmpty()) {
                    break;			// Nothing? We must be done
                }

                for (Status s : r.getTweets()) // Loop through all the tweets...
                {// second
                    totalTweets++;

                    tweetsids = tweetsid + ids;
                    if (maxID == -1 || s.getId() < maxID) {
                        maxID = s.getId();
                    }
                    String data = demotwitter.cleanText(s.getText());
                    demotwitter.str = data.split("https:");
                    String datautc = String.valueOf(TimeZoneId.timezoneutc(location));
                    String[] utcdata = datautc.split("#");
                    username = s.getUser().getName();
                    String[] udata = username.split(" ");
                    Long sss = s.getUser().getId();
                    System.out.println("D" + sss);
//                    String udataname;
//                    if (udata.length > 0) {
//                        udataname = udata[0].toString();
//                    } else {
//                        udataname = udata[0].toString();
//                    }
                    gender = genderizeiddata();// genderizeid(udataname);
                    userScreenName = s.getUser().getScreenName().replace("'", "");
                    createddate = s.getUser().getCreatedAt().toString();
                    SimpleDateFormat myFormat = new SimpleDateFormat("dd/MM/yyyy");
                    Date dt1 = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy").parse(createddate);
                    String date1 = myFormat.format(dt1);
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    Date birthDate = sdf.parse(date1); //Yeh !! It's my date of birth :-)
                    AgeCalculator aa = new AgeCalculator();
                    age = aa.AgeCalculator(birthDate);// only year
                    profilename = s.getUser().getProfileImageURL();
                    // location = s.getUser().getLocation().replace("'", "");

                    tweentpost = demotwitter.str[0].toString().replace("'", "");
                    desc = s.getUser().getDescription().toString().replace("'", "");
                    String post = tweentpost + desc;
                    RemoveStopwords rm = new RemoveStopwords();
                    String result = rm.RemoveWords(tweentpost.toLowerCase());
                    Stemmer ss = new Stemmer();
                   
                    String searchtexts = username + "####0" + userScreenName + "####0" + createddate + "####0" + profilename + "####0" + gender + "####0" + post+"####0"+topics;

                    demotwitter.alllistdata.add(searchtexts);
                    ids++;
                }//for loop end second

                searchTweetsRateLimit = r.getRateLimitStatus();
            }// for loop end first

        } catch (InterruptedException | TwitterException e) {
             System.err.println(e);
             e.printStackTrace();
        } catch (SQLException ex) {
             System.err.println(ex);
             ex.printStackTrace();
            //Logger.getLogger(demotwitter.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
             System.err.println(ex);
             ex.printStackTrace();
            //Logger.getLogger(demotwitter.class.getName()).log(Level.SEVERE, null, ex);
        }
//        File Nfpath = new File("F://AllData.txt");
//        try {
//            FileOutputStream fos = new FileOutputStream(Nfpath);
//            bw = new BufferedWriter(new OutputStreamWriter(
//                    fos));
//            for (String s : demotwitter.alllistdata) {
//                bw.write(s);
//                bw.newLine();
//            }
//            bw.close();
//        } catch (FileNotFoundException ex) {
//
//        } catch (IOException ex) {
//
//        }
    }

    public static int datecount1(String dateBeforeString) {
        int daysBetween = 0;
        try {
            SimpleDateFormat myFormat = new SimpleDateFormat("dd/MM/yyyy");//SimpleDateFormat("dd/MM/yyyy");
            try {
                Date dateBefore = myFormat.parse(dateBeforeString);
                Date dateAfter = new Date();
                //            System.out.println("Starting Date=>" + dateBeforeString + "\tCurrent Date=>" + dateAfter);
                long difference = dateAfter.getTime() - dateBefore.getTime();
                daysBetween = (int) (difference / (1000 * 60 * 60 * 24));
                //System.out.println("Number of Days between dates: " + daysBetween);
            } catch (ParseException e) {
            }
        } catch (Exception ex) {
            // Logger.getLogger(demotwitter.class.getName()).log(Level.SEVERE, null, ex);
        }
        return daysBetween;
    }

    public static int datecount(String dateBeforeString) {
        int daysBetween = 0;
        try {
            SimpleDateFormat myFormat = new SimpleDateFormat("dd/MM/yyyy");

            Date dt1 = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy").parse(dateBeforeString);

            String date1 = myFormat.format(dt1);

            try {
                Date dateBefore = myFormat.parse(date1);
                Date dateAfter = new Date();
                //            System.out.println("Starting Date=>" + dateBeforeString + "\tCurrent Date=>" + dateAfter);
                long difference = dateAfter.getTime() - dateBefore.getTime();
                daysBetween = (int) (difference / (1000 * 60 * 60 * 24));
                //System.out.println("Number of Days between dates: " + daysBetween);
            } catch (ParseException e) {
            }
        } catch (ParseException ex) {
            // Logger.getLogger(demotwitter.class.getName()).log(Level.SEVERE, null, ex);
        }
        return daysBetween;
    }

    public static String Timezone() {

        String[] id = TimeZone.getAvailableIDs();
        for (String id1 : id) {
            TimeZone timezone1 = TimeZone.getTimeZone(id1);
            // checking offset value for date
            System.out.println(id1 + "Offset value:" + timezone1.getOffset(Calendar.ZONE_OFFSET));
        }
        return null;
    }

    public static void main(String[] args) {
//        createaccount();
        String dateBeforeString = "2017-09-26";
        // datecount(dateBeforeString);
        int a = dateBeforeString.indexOf("-");
        if (a != -1) {
            String[] day = dateBeforeString.split("-");
            String date = day[2] + "/" + day[1] + "/" + day[0];
            datecount1(date);
            System.out.println(a);
        } else {
            datecount(dateBeforeString);
            System.out.println(a);
        }

    }

    private static String displayTimeZone(TimeZone tz) {

        long hours = TimeUnit.MILLISECONDS.toHours(tz.getRawOffset());
        long minutes = TimeUnit.MILLISECONDS.toMinutes(tz.getRawOffset())
                - TimeUnit.HOURS.toMinutes(hours);
        // avoid -4:-30 issue
        minutes = Math.abs(minutes);

        String result;
        if (hours > 0) {
            result = String.format("(GMT+%d:%02d) %s", hours, minutes, tz.getID());
        } else {
            result = String.format("(GMT%d:%02d) %s", hours, minutes, tz.getID());
        }

        return result;

    }
}
