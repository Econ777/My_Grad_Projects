/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataCreation;

//import static Master.Dbconn.file70path;
import static Master.Dbconn.negative;

import static Master.MasterPage.enegative2;
import static Master.MasterPage.epositive2;
import Preprocess.emoticon;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/**
 *
 * @author JP
 */
public class semantic_features {

    public static int exclamation_marks = 0, question_marks = 0, full_stop_marks = 0, quotes_marks = 0, interjections_marks = 0, laughing_expressions = 0,capitalword=0;

    public static int exclamation_marks(String msg) {
        String[] tokens = msg.split("\\P{Alpha}+");// \\p is use for space and
        for (String s : tokens) {
            if (s.contains("!")) {
                exclamation_marks++;
            }
        }
        return exclamation_marks;
    }


    public static int laughing_expressions(String msg) {
        String[] tokens = msg.split("\\P{Alpha}+");// \\p is use for space and
        for (String s : tokens) {
            
            
            if (s.contains("😛")||s.contains("😝")||s.contains("😜")||s.contains("😆")||s.contains("😅")||s.contains("😄")||s.contains("😃")||s.contains("😛")||s.contains("😁")||s.contains("😀")) {
                laughing_expressions++;
            }
        }
        return laughing_expressions;
    }
    

public static String join(Collection<String> s, String delimiter) {
        StringBuffer buffer = new StringBuffer();
        Iterator<String> iter = s.iterator();
        while (iter.hasNext()) {
            buffer.append(iter.next());
            if (iter.hasNext()) {
                buffer.append(delimiter);
            }
        }
        return buffer.toString();
    }
        
        
    }

