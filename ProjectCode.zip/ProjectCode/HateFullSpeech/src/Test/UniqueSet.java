/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Test;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Sunsoft
 */
public class UniqueSet {
    public static int GetLen(StringBuilder strdata){
    int len=0;
    String str=strdata.toString();
    Set<String> myset=new HashSet<>();
    String s[]=str.split(",");

    for(int i=1;i<s.length;i++){

            myset.add(s[i]);

     }

     for (String sss: myset){
           len++;

    }
     return len;
  }
}